import cartodup.interpreter as interpreter


def main():
    interpreter.configure()
